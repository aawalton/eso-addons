ESODBGameDataExportConst = {}

ESODBGameDataExportConst.ChestNames = {
	["chest"] = true,
	["truhe"] = true,
	["coffre"] = true,
}

ESODBGameDataExportConst.PsijikPortalNames = {
	["psijic portal"] = true,
	["psijik-portal"] = true,
	["portail psijique"] = true,
}

ESODBGameDataExportConst.ThievesTroveNames = {
	["thieves trove"] = true,
	["diebesgut"] = true,
	["trésor des voleurs"] = true,
}